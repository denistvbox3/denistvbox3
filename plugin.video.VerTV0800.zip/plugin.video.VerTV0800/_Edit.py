import xbmcaddon

MainBase = 'http://vertv0800.com/addon-kodi'
addon = xbmcaddon.Addon('plugin.video.VerTV0800')