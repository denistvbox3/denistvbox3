import xbmcaddon

MainBase = 'https://gist.githubusercontent.com/Gunboybr/41bf6b504fc14a12c3a8eee86c987579/raw/a64c50c75ce095fe3b71fb7ab2b600052cac669a/MegaboxFilmesLista'
addon = xbmcaddon.Addon('plugin.video.tvmovies')