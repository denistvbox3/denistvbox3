#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright 2014
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


##############BIBLIOTECAS A IMPORTAR E DEFINICOES####################
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import urllib2,urllib
import re
import extract
import time
import downloader
import zipfile
import ntpath
import base64
import zlib

def decode_base64_and_inflate( b64string ):
    decoded_data = base64.b64decode( b64string )
#    print ord(decoded_data[0])
    return zlib.decompress( decoded_data , 15)

	
def deflate_and_base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string =zlibbed_str## zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )

	
exec(decode_base64_and_inflate('eJydWP1y2zYS/zt8CgwzLcmapiQ3aRr5eBnZlhMlsuSx5FyvqsZDkZCEmgQYArItd/o09yj3Yl0A/NJH1bT0jA1gP/HDYndho3NxMRz4T7MkDKKIUa8jf9sk8q00Xi0I9R5IhJl3070eHveHH3uDT5aDEDIiEsRsgXwkRRcr4l2oBVsSkfG5ezPqDQdANlte0zsxjevO+IOcJusFI5EXMhPVPiMm9B5zYLDwx+f+p/P79FN/Nmqt3/b6568/jsPsqtl8GD6/vX0Ykeef+o9vHq+u+Ml63PnQuWr8fP7mv75lzLIVZaBiFnD8wytv9sOrCIcswgZ8EZ6j8864+3540+uObKf9UtPuNPNdQKM7QudxILCtfXEM6Zgcg8rhdXdwd3vTt/9SSoslgQiXIJdh2GmSkhjbFg0S7Ju2d/TOMX/h362yuDYjyaI2mwc0yERtIcI8zEgqCKPFquV4c0KjII6VaW13zjIk7big3SUhoyQJFtjV+tyaFkSodrJtFGcA539BMrsUbx1U4JRyamC8UBCXOIECR6vO8BcAAuYxmZ14N/jLCnOh6AXZA8t3SxxEOLOtW46z484CU2G5yLpizySOg8Zrr4ns/8B22SM/RbenKB+jwRi99lqnCNPj92enKHtot7y3EHHfO+g9Du9Z46TZ/LH59uRV6w26JBmes6fG95JuFeZ5yijHNRfhL0sxtcGzKgb8gtHLwFF7U9gLY8ZxuShWGVVCRgWPBOeRPAdZVAFcR1NjFS4ZCfGeS+WtMafMtibnw/7wBj0uicDTydkUbu+xumaTxtl00lDUqXWkTNTUuyAeBzMc+7kGf5FhTKecJC4CPvwrg4DgIoiDrNTiUrYpk+FoSv//P/bnIhoBMi834qNmFWAaGTXF8QZTq2JKA84NPRDLHAlPZAHl8pZdw6LNuCeJ3q+MUNviKQ4BpXajsWQJbqgsxi3XSoPwHkKXW/mVjNIdXK8zBjhwbhccXginC3fZVFkRjbr97jmksc7F0HTNs07vp87gYohM15KxeQ0Hcdn5DL+7o+vuTdcqomXmb3goR666lUeW90zSnE9k63LXwJ/hhD3ILDLTZPwU4lSUHCUsEPU0ZvKueMVQXiZX2oWDSbW0QmHOYmD75xjmwAmSYI/HGKf2SQnUKo0kUE3XNF1k9gajcaevwNlGxdQiaUaoQJb/dZ9Vk6lt5R9rwk+w+1B4OlnO3JpOt4DsVu3oSl7jF/mPvLTVcnsj4clP4YqfcLgSeLYisQAsTS3QZ2EQq1rKTedrBBTvDU4Z8G+Z0aXW384JpznBo0yQOQkDedNVdjmSh6IGyEQfOme9fm+sYrhM6GDiRV4Vt9N+AvXtcOavLuvK52vuBdniYdKcHpnvVE070onU+7JiAt9BF8FVtj8yv5Wqgc5FZsuhXNJFcY+IJEiG0pO9XNWGgLWomnv4NEkybVTSPZx7Sxy798fZCpfzmDyXx9EnXPQETjSCSHrU0/5e4HmwisWlijMvpQs4FbFcJTMakFjzVP6/hL6CLBiarZHuY5aQfaG81216HIsexK2NxDoFA59lawZKoQVhfZmquf8bMsdExNhs6z4AmdcxEzCr1/7fkbOtFlJhijOxtpF5qbC6Uw6Ccg0d2gBD7j1vD3X44FCwbK1gWILXMeyMCrsMjtbUkbHlr9wY0ILalfhg1yVcY+NfBjHHzlahAEObPUb9TqjQXWBxlwZZkEAGr1cQWPEn080FCDpCF1W8nlR0KEUxlnm6ZHP+7Z9UCjf17FVRfGGMA4qjnFP/gdSexkEIHeA7KEuWsyME9nPjk8oP57g1hfTVsJxdR7YcymWb7br0HufSgGSczXOpDVc9nsZE2Na3e9zTeP72+w5BNptENpJQWRZQupT1mgnngOvKXu7JHtX72DZ0T8i08Nnf43PxSWilXzU9juPvO9y9u57U5CDDTf36vLWL8Pa3HdFKcieot4Xy/daj25C3Z8AoNlTCVCOVTdWoypFqmudBNa6nO7VgGPXGA6lbqZPgitbSYL5HE2jm1DG2uhHdjmwoUn4d0iQZvk5VtZ1D+kqug0p3sFaoyeRU6JELf09Fju8h5zTL31NbP6pDumt8f2pgR7mh2yZZeuVL3Dmy2shSlTh/qjs5h3kFeLRRrUoXBHjWFevq9ZYvD+Bci3VVtAtCr6iEBbUqdnnrAXXnM8GPNqwLePC56AFmYyhteeJ4KTlQTlU1D3EmG90syNaIL+UDMGEZVnIcQeFRpbB8hGjBCppa2QLF55ps71SqQrB8zajXgAf3cYQFtGwL2wpWgh1LqxZkE0tAb2Btmtnp8qS1gFBoBEZ61xJn+xvumOibXQMlEMjZc5bgkgpjdaMRZGF5i8uJzHfygP5Ve1XV//VR1lL1CNOKaqyHXqmVC9WoBiqm0XBedgM7wDrGHyeChG0='))

